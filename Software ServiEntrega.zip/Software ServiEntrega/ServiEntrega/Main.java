import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);

    private static int Opciones() {
        System.out.println("Seleccione el tipo de envío:");
        System.out.println("1. Envío Estándar");
        System.out.println("2. Envío Urgente");
        System.out.println("3. Envío Frágil");
        System.out.print("Ingrese su opción: ");
        int opcion = 0;
        try {
            opcion = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un número válido.");
            scanner.nextLine(); // Consumir la entrada inválida
            opcion = Opciones(); // Llamar recursivamente al método
        }
        scanner.nextLine(); // Consumir el salto de línea
        return opcion;
    }
    
    private static EnvioEstandar NuevoEnvioEstandar(Scanner scanner, int intentosRestantes) {
        if (intentosRestantes == 0) {
            System.out.println("Demasiados intentos fallidos. Finalizando el programa.");
            System.exit(1);  
        }
        // Solicita al usuario que ingrese el ID del envío
        System.out.println("Ingresa el ID del envío: ");
        int IdEnvio = 0;
        try {
            IdEnvio = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un numero valido para el ID del envio.");
            scanner.nextLine(); //Consumir la entrada invalida
            return NuevoEnvioEstandar(scanner, intentosRestantes -1); //Llamar recursivamente al metodo           
        }
    
        scanner.nextLine(); // Consume el caracter de salto de línea
        
        // Solicita al usuario que ingrese la dirección de origen
        System.out.println("Ingresa la dirección de origen: ");
        String DireccionOrigen = scanner.nextLine();
        
        // Solicita al usuario que ingrese la dirección de destino
        System.out.println("Ingresa la dirección de destino: ");
        String DireccionDestino = scanner.nextLine();
        
        // Solicita al usuario que ingrese el peso del envío (en kg)
        System.out.println("Ingresa el peso (kg): ");
        double Peso = 0.0;
        try {
            Peso = scanner.nextDouble();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un numero valido para el peso.");
            scanner.nextLine(); // Consumir la entrada invalida
            return NuevoEnvioEstandar(scanner, intentosRestantes -1); //Llamar recursivamente al metodo
        }
    
        scanner.nextLine(); //Consume el caracter de salto de linea
        
        // Solicita al usuario que ingrese las dimensiones del envío (largo, ancho, alto) separadas por espacios
        System.out.println("Ingresa las dimensiones (largo, ancho, alto) separadas por espacios: ");
        double largo = 0.0, ancho = 0.0, alto = 0.0;
        try {
                largo = scanner.nextDouble();
                ancho = scanner.nextDouble();
                alto = scanner.nextDouble();    
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese numeros validos para las dimensiones.");
            scanner.nextLine(); //Consumir la entrada invalida
            return NuevoEnvioEstandar(scanner, intentosRestantes -1); //Llamar resurviamente al metodo
        }
            
        // y retorna el objeto creado
        return new EnvioEstandar(IdEnvio, DireccionOrigen, DireccionDestino, Peso, new double[]{largo, ancho, alto});
    }
        
    private static EnvioUrgente NuevoEnvioUrgente(Scanner scanner, int intentosRestantes) {
        if (intentosRestantes == 0) {
            System.out.println("Demasiados intentos fallidos. Finalizando el programa.");
            System.exit(1);
        }
    
        // Solicita al usuario que ingrese el ID del envío
        System.out.println("Ingresa el ID del envío: ");
        int IdEnvio = 0;
        try {
            IdEnvio = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un numero valido para el ID del envio.");
            scanner.nextLine(); //Consumir la entrada invalida
            return NuevoEnvioUrgente(scanner, intentosRestantes -1); //Llamar recursivamente al metodo 
        }
        scanner.nextLine(); // Consume el caracter de salto de línea
        
        // Solicita al usuario que ingrese la dirección de origen
        System.out.println("Ingresa la dirección de origen: ");
        String DireccionOrigen = scanner.nextLine();
        
        // Solicita al usuario que ingrese la dirección de destino
        System.out.println("Ingresa la dirección de destino: ");
        String DireccionDestino = scanner.nextLine();
        
        // Solicita al usuario que ingrese el peso del envío (en kg)
        System.out.println("Ingresa el peso (kg): ");
        double Peso = 0.0;
        try {
            Peso = scanner.nextDouble();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un numero valido para el peso.");
            scanner.nextLine(); // Consumir la entrada invalida
            return NuevoEnvioUrgente(scanner, intentosRestantes -1); //Llamar recursivamente al metodo
        }
    
        scanner.nextLine();
        
        // Solicita al usuario que ingrese las dimensiones del envío (largo, ancho, alto) separadas por espacios
        System.out.println("Ingresa las dimensiones (largo, ancho, alto) separadas por espacios: ");
        double largo = 0.0, ancho = 0.0, alto = 0.0;
        try {
            largo = scanner.nextDouble();
            ancho = scanner.nextDouble();
            alto = scanner.nextDouble();    
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese numeros validos para las dimensiones.");
            scanner.nextLine(); //Consumir la entrada invalida
            return NuevoEnvioUrgente(scanner, intentosRestantes -1); //Llamar resurviamente al metodo
        }
        
        // Solicita al usuario que ingrese el recargo urgente (porcentaje)
        System.out.println("Ingrese el recargo urgente (porcentaje, ej 0.3 para 30%): ");
        double RecargoUrgente = 0.0;
        try {
            RecargoUrgente = scanner.nextDouble();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese numeros validos para el recargo urgente.");
            scanner.nextLine();
            return NuevoEnvioUrgente(scanner, intentosRestantes -1);
        }
        
        // Crea un nuevo objeto EnvioUrgente con los datos ingresados por el usuario
         // y retorna el objeto creado
        return new EnvioUrgente(IdEnvio, DireccionOrigen, DireccionDestino, Peso, new double[]{largo, ancho, alto}, RecargoUrgente);
    }
    
    private static EnvioFragil NuevoEnvioFragil(Scanner scanner, int intentosRestantes) {
    
        if (intentosRestantes == 0) {
            System.out.println("Demasiados intentos fallidos. Finalizando el programa.");
            System.exit(1);
        }
    
        // Solicita al usuario que ingrese el ID del envío
        System.out.println("Ingresa el ID del envío: ");
        int IdEnvio = 0;
        try {
            IdEnvio = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un numero valido para el ID del envio.");
            scanner.nextLine(); //Consumir la entrada invalida
            return NuevoEnvioFragil(scanner, intentosRestantes -1); //Llamar recursivamente al metodo 
        }
        scanner.nextLine(); // Consume el caracter de salto de línea
        
        // Solicita al usuario que ingrese la dirección de origen
        System.out.println("Ingresa la dirección de origen: ");
        String DireccionOrigen = scanner.nextLine();
        
        // Solicita al usuario que ingrese la dirección de destino
        System.out.println("Ingresa la dirección de destino: ");
        String DireccionDestino = scanner.nextLine();
        
        // Solicita al usuario que ingrese el peso del envío (en kg)
        System.out.println("Ingresa el peso (kg): ");
        double Peso = 0.0;
        try {
            Peso = scanner.nextDouble();
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un numero valido para el peso.");
            scanner.nextLine(); // Consumir la entrada invalida
            return NuevoEnvioFragil(scanner, intentosRestantes -1); //Llamar recursivamente al metodo
        }
    
        scanner.nextLine();
        
        // Solicita al usuario que ingrese las dimensiones del envío (largo, ancho, alto) separadas por espacios
        System.out.println("Ingresa las dimensiones (largo, ancho, alto) separadas por espacios: ");
        double largo = 0.0, ancho = 0.0, alto = 0.0;
        try {
            largo = scanner.nextDouble();
            ancho = scanner.nextDouble();
            alto = scanner.nextDouble();    
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese numeros validos para las dimensiones.");
            scanner.nextLine(); //Consumir la entrada invalida
            return NuevoEnvioFragil(scanner, intentosRestantes -1); //Llamar resurviamente al metodo
        }
        
        // Solicita al usuario que ingrese el recargo frágil (porcentaje)
        System.out.println("Ingrese el recargo frágil (porcentaje, ej 0.2 para 20%): ");
        double RecargoFragil = scanner.nextDouble();
        
        // Crea un nuevo objeto EnvioFragil con los datos ingresados por el usuario
        // y retorna el objeto creado
        return new EnvioFragil(IdEnvio, DireccionOrigen, DireccionDestino, Peso, new double[]{largo, ancho, alto}, RecargoFragil);
    }

    public static void MostrarCostos(double CostoEstandar, double CostoUrgente, double CostoFragil){
        // Imprime un encabezado para la sección de costos de envío
        System.out.println("\nCostos de envío:");
        
        // Imprime el costo del envío estándar
        System.out.println("Costo envío Estándar: " + CostoEstandar);
        
        // Imprime el costo del envío urgente
        System.out.println("Costo envío Urgente: " + CostoUrgente);
        
        // Imprime el costo del envío frágil
        System.out.println("Costo envío Frágil: " + CostoFragil);
    }
    
    public static void main(String[] args) {

        int opcion = Opciones();

        GestorEnvios gestor = new GestorEnvios();

        switch (opcion) {
            case 1:
            // Creación de un envío estándar
            System.out.println("\nIngresa los datos del envío estándar: ");
            EnvioEstandar envioEstandar = NuevoEnvioEstandar(scanner, 3);
            gestor.RegistrarEnvio(envioEstandar);
            
            // Cálculo del costo del envío estándar
            double CostoEstandar = gestor.CalcularCostoEnvio(envioEstandar);
            
            // Mostrar los costos de los envíos
            MostrarCostos(CostoEstandar, 0, 0);
            break;
            case 2:
            // Creación de un envío urgente
            System.out.println("\nIngrese los datos del envío urgente: ");
            EnvioUrgente envioUrgente = NuevoEnvioUrgente(scanner, 3);
            gestor.RegistrarEnvio(envioUrgente);
            
            // Cálculo del costo del envío urgente
            double CostoUrgente = gestor.CalcularCostoEnvio(envioUrgente);
            
            // Mostrar los costos de los envíos
            MostrarCostos(0, CostoUrgente, 0); // Solo el costo del envío urgente
            break;
            case 3:
            // Creación de un envío frágil
            System.out.println("\nIngrese los datos del envío frágil: ");
            EnvioFragil envioFragil = NuevoEnvioFragil(scanner, 3);
            gestor.RegistrarEnvio(envioFragil);
            
            // Cálculo del costo del envío frágil
            double CostoFragil = gestor.CalcularCostoEnvio(envioFragil);
            
            // Mostrar los costos de los envíos
            MostrarCostos(0, 0, CostoFragil); // Solo el costo del envío frágil
            break;
        default:
            System.out.println("Opción inválida. Saliendo del programa.");
            System.exit(1);
        }

        // Cerrar el Scanner
        scanner.close();
    }
}
