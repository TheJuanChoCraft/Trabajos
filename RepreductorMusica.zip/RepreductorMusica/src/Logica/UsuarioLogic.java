package Logica;

public class UsuarioLogic {
    private static UsuarioDAO usuariodao = new UsuarioDAO();
    
    public static boolean autentificar(String usuario, String contraseña){
    Usuario usuarioConsulta = obtener(usuario);
    
    // Imprimir el usuario obtenido
    System.out.println("Usuario obtenido: " + usuarioConsulta);
    
    if (usuarioConsulta != null){
        // Imprimir el nombre de usuario y la contraseña del usuario obtenido
        System.out.println("Nombre de usuario: " + usuarioConsulta.getUsuario());
        System.out.println("Contraseña: " + usuarioConsulta.getContraseña());
        
        if (usuarioConsulta.getUsuario().equals(usuario) && usuarioConsulta.getContraseña().equals(contraseña)){
            return true;
        }
    }
    
    return false;
}
    public static boolean insertar(Usuario usuario){
    
        return usuariodao.insertar(usuario);
    }
    
    public static Usuario obtener(String usuario){
    
        return usuariodao.obtener(usuario);
    }
}
