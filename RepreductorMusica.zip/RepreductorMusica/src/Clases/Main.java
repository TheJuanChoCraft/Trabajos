package Clases;

import Ventanas.Inicio;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Inicio ventana = new Inicio();
                ventana.setVisible(true);
            }
        });
    }
    
}
