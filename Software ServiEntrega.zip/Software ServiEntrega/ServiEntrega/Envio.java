public abstract class Envio{

    // Atributos que representan las características básicas de un envío
    protected int IdEnvio;
    protected String DireccionOrigen;
    protected String DireccionDestino;
    protected double Peso;
    protected double[] Dimensiones;

    // Constructor que inicializa las propiedades del envío
    public Envio(int IdEnvio, String DireccionOrigen, String DireccionDestino, double Peso, double[] Dimensiones){
        this.IdEnvio=IdEnvio;
        this.DireccionOrigen=DireccionOrigen;
        this.DireccionDestino=DireccionDestino;
        this.Peso=Peso;
        this.Dimensiones=Dimensiones;
    }

    // Método abstracto que debe ser implementado por las clases derivadas para calcular el costo base del envío
    // Este método debe tener en cuenta las características específicas del tipo de envío
    public abstract double CalcularCostoBase();
    
}