package Logica;

public class Usuario {
    
    private String NombreCompleto;
    private String Correo;
    private String Contraseña;
    private String usuario;

    public Usuario(String NombreCompleto, String Correo, String Contraseña) {
        this.NombreCompleto = NombreCompleto;
        this.Correo = Correo;
        this.Contraseña = Contraseña;
    }
    public String getUsuario() {
        return this.usuario;
    }

    public String getNombreCompleto() {
        return NombreCompleto;
    }

    public void setNombreCompleto(String NombreCompleto) {
        this.NombreCompleto = NombreCompleto;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }
    
    public String getContraseña() {
        return Contraseña;
    }
    
    public void setContraseña(String contraseña) {
        this.Contraseña = Contraseña;
    }

    

    
    
}
