public class EnvioEstandar extends Envio {

    // Constantes que definen los parámetros de costo para envíos estándar
    private static final double TarifaBase=5000; // Tarifa base por envío
    private static final double CostoKG=2000;    // Costo por kilogramo adicional de peso
    private static final double CostoCM3=0.1;    // Costo por centímetro cúbico de volumen

    // Constructor que hereda las propiedades del envío de la clase base
    public EnvioEstandar(int IdEnvio, String DireccionOrigen, String DireccionDestino, double Peso, double[] Dimensiones){
        super(IdEnvio, DireccionOrigen, DireccionDestino, Peso, Dimensiones);
    }

    // Método que sobrescribe el método abstracto de la clase base para calcular el costo base de un envío estándar
    @Override
    public double CalcularCostoBase() {

        // Cálculo del costo base por peso
        double CostoBasePeso = Math.max(0, Peso - 1) * CostoKG; // Se resta 1 kg y se toma el máximo entre 0 y el resultado

        // Cálculo del volumen del envío
        double Volumen = Dimensiones[0] * Dimensiones[1] * Dimensiones[2];

        // Cálculo del costo base por volumen
        double CostoBaseVolumen = Volumen * CostoCM3;

        // Cálculo del costo base total
        return TarifaBase + CostoBasePeso + CostoBaseVolumen;
        
    }
}
