package Ventanas;

public class Lista {
    
    Nodo first;
    Nodo last;
    
    public static int tam;
    
    public Lista(){
        first = null;
        last = null;
        tam = 0;
    }
    
    public boolean IsEmpty(){
        if(first == null && last == null){
            return true;
        } else {
            return false;
        }
    }
    
    public void clear(){
        while(!IsEmpty()){
            borrar(first);
        }
    }
    
    public void insertar(String nom, String dir) {
    Nodo nuevo = new Nodo(nom, dir);
    if (first == null) {
        first = nuevo;
        last = nuevo;
    } else {
        last.siguiente = nuevo;
        nuevo.anterior = last;
        last = nuevo;
    }
    tam++;
    }
    
    public int Size(){
        if(IsEmpty()){
            return 0;
        } else {
            return tam;
        }
    }
    
    public int index(Nodo b){
        Nodo aux = first;
        int con = 0;
        do{
            if(aux == b){
                return con;
            }
            aux = aux.siguiente;
            con++;
        } while(aux != first);
        return -1;
    }
    
    public Nodo get_cancion(int index){
        if(index < 0 || index >= tam){
            return null;
        }
        int n = 0;
        Nodo aux = first;
        while(n != index){
            aux = aux.siguiente;
            n++;
        }
        return aux;
    }
    
    public void borrar(Nodo d){
        boolean encontrado = false;
        Nodo actual = first;
        Nodo anterior = last;
        do{
            if(d == first){
                if(actual == first){
                    first = first.siguiente;
                    last.siguiente = first;
                    first.anterior = last;
                } else if(actual == first){
                    last = anterior;
                    first.anterior = last;
                    last.siguiente = first;
                } else{
                    anterior.siguiente = actual.siguiente;
                    actual.siguiente.anterior = anterior;
                }
                encontrado = true;
            }
            anterior = actual;
            actual = actual.siguiente;
        } while(actual != first && encontrado == false);
    }
}
