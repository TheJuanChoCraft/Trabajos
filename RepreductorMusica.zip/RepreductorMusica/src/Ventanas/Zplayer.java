package Ventanas;

import Logica.*;
import Ventanas.Pagina1;
import javazoom.jlgui.basicplayer.BasicController;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerEvent;
import javazoom.jlgui.basicplayer.BasicPlayerListener;

import java.util.Map;

public class Zplayer implements BasicPlayerListener {

    BasicPlayer player = new BasicPlayer();
    BasicController control = (BasicController) player;

    Pagina1 pg;

    public Zplayer(Pagina1 v){
        player.addBasicPlayerListener(this);
        pg = v;
    }

    @Override
    public void opened(Object o, Map properties){

    }

    @Override
    public void stateUpdated(BasicPlayerEvent event){
        if(player.getStatus() == BasicPlayer.STOPPED && pg.detenido == false){
            pg.eventoSiguiente();
        }
    }

    @Override
    public void progress(int bytesread, long microseconds, byte[] pcmdata, Map properties){

    }

    @Override
    public void setController(BasicController controller){

    }
}