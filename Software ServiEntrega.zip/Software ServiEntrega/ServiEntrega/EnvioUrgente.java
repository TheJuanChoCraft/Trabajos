public class EnvioUrgente extends Envio {

    // Constante que define el recargo por envío urgente
    private static final double RecargoUrgente = 0.3; // 30% de recargo

    // Constructor que hereda las propiedades del envío de la clase base
    public EnvioUrgente(int IdEnvio, String DireccionOrigen, String DireccionDestino, double Peso, double[] Dimensiones, double Recargo) {
        super(IdEnvio, DireccionOrigen, DireccionDestino, Peso, Dimensiones);

        // Se valida que el recargo sea mayor que cero
        if (Recargo <= 0) {
            throw new IllegalArgumentException("El recargo debe ser un valor mayor que cero");
        }
    }

    // Método que sobrescribe el método abstracto de la clase base para calcular el costo base de un envío urgente
    @Override
    public double CalcularCostoBase() {

        // Se crea una instancia de EnvioEstandar para calcular el costo base estándar
        EnvioEstandar envioEstandar = new EnvioEstandar(IdEnvio, DireccionOrigen, DireccionDestino, Peso, Dimensiones);

        // Se obtiene el costo base estándar
        double costoBaseEstandar = envioEstandar.CalcularCostoBase();

        // Se calcula el costo base total aplicando el recargo por envío urgente
        return costoBaseEstandar * (1 + RecargoUrgente);

    }
}
