public class EnvioFragil extends Envio {

    // Constante que define el recargo por envío frágil
    private static final double RecargoFragil = 0.2; // 20% de recargo

    // Constructor que hereda las propiedades del envío de la clase base
    public EnvioFragil(int IdEnvio, String DireccionOrigen, String DireccionDestino, double Peso, double[] Dimensiones, double recargo) {
        super(IdEnvio, DireccionOrigen, DireccionDestino, Peso, Dimensiones);

        // Se valida que el recargo sea mayor que cero
        if (recargo <= 0) {
            throw new IllegalArgumentException("El recargo debe ser un valor mayor que cero");
        }
    }

    // Método que sobrescribe el método abstracto de la clase base para calcular el costo base de un envío frágil
    @Override
    public double CalcularCostoBase() {

        // Se crea una instancia de EnvioEstandar para calcular el costo base estándar
        EnvioEstandar envioEstandar = new EnvioEstandar(IdEnvio, DireccionOrigen, DireccionDestino, Peso, Dimensiones);

        // Se obtiene el costo base estándar
        double costoBaseEstandar = envioEstandar.CalcularCostoBase();

        // Se calcula el costo base total aplicando el recargo por envío frágil
        return costoBaseEstandar * (1 + RecargoFragil);
        
    }
}
