package Ventanas;

import Logica.*;

public class Nodo {
    
    String nombre, direccion;
    Nodo siguiente;
    Nodo anterior;
    
    public Nodo(String nombre, String direccion){
        this.nombre = nombre;
        this.direccion = direccion;
        siguiente = null;
        anterior = null;
    }
    
}
