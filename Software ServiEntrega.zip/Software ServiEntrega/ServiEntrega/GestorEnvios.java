import java.util.ArrayList;
import java.util.List;

public class GestorEnvios {

    // Lista para almacenar los envíos registrados
    private List<Envio> envios;

    // Constructor que inicializa la lista de envíos
    public GestorEnvios() {
        this.envios = new ArrayList<>();
    }

    // Método para registrar un nuevo envío
    public void RegistrarEnvio(Envio envio) {
        // Se añade el envío a la lista de envíos
        envios.add(envio);
    }

    // Método para calcular el costo de un envío específico
    public double CalcularCostoEnvio(Envio envio) {

        // Se verifica si el envío es de tipo urgente
        if (envio instanceof EnvioUrgente) {
            // Si es urgente, se llama al método `CalcularCostoBase()` de la clase `EnvioUrgente` para obtener el costo
            return ((EnvioUrgente)envio).CalcularCostoBase();
        } else if (envio instanceof EnvioFragil) {
            // Si es frágil, se llama al método `CalcularCostoBase()` de la clase `EnvioFragil` para obtener el costo
            return ((EnvioFragil)envio).CalcularCostoBase();
        } else {
            // Si no es urgente ni frágil, se llama al método `CalcularCostoBase()` de la clase `Envio` para obtener el costo
            return envio.CalcularCostoBase();
        }
        
    }
}

